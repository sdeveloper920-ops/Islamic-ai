# ISLAMIC AI — Starter Project

এটি একটি প্রাথমিক Flask + OpenAI API ওয়েব অ্যাপ। এতে বাংলা/ইংরেজি চ্যাট UI, Backend API,
Admin Login এবং সাম্প্রতিক প্রশ্ন-উত্তরের তালিকা আছে।

## গুরুত্বপূর্ণ
- এই প্রজেক্টে AI চালাতে একটি বৈধ OpenAI API key এবং API billing/credits প্রয়োজন।
- API key কখনো HTML/JavaScript-এ বা GitHub-এ লিখবেন না। শুধু Hosting-এর Environment Variables-এ দিন।
- AI উত্তরকে ফতোয়া হিসেবে ব্যবহার করবেন না। গুরুত্বপূর্ণ মাসআলা যোগ্য আলেম/মুফতির কাছে যাচাই করুন।
- এই Starter-এ SQLite ব্যবহার করা হয়েছে। Free hosting-এর ephemeral filesystem-এ redeploy/restart হলে
  ডেটা হারাতে পারে। বাস্তব ব্যবহারকারীর ডেটার জন্য persistent disk বা managed PostgreSQL যুক্ত করুন।
- Admin login-এর জন্য শক্তিশালী ADMIN_PASSWORD এবং APP_SECRET দিন। ডিফল্ট admin password সেট করা নেই।

## লোকালি চালানো
1. Python 3.11+ ইনস্টল করুন।
2. `pip install -r requirements.txt`
3. `.env.example` কপি করে `.env` বানান এবং environment variables সেট করুন।
4. Linux/macOS: `export OPENAI_API_KEY=...` ইত্যাদি; Windows PowerShell: `$env:OPENAI_API_KEY="..."`
5. `python app.py`
6. ব্রাউজারে `http://127.0.0.1:5000` খুলুন।
7. Admin: `http://127.0.0.1:5000/admin/login`

## Render-এ Deploy
1. পুরো ফোল্ডারের ফাইল GitHub repository-তে আপলোড করুন।
2. Render-এ New > Blueprint অথবা New Web Service দিয়ে repository যুক্ত করুন।
3. Environment Variables-এ `ADMIN_PASSWORD` এবং `OPENAI_API_KEY` দিন।
4. `APP_SECRET`-এ দীর্ঘ random secret দিন (Blueprint generate করলে সেটি ব্যবহার করুন)।
5. Deploy সম্পন্ন হলে পাওয়া `onrender.com` URL খুলুন।
6. Admin login: `https://YOUR-SITE/admin/login`

## বর্তমান সীমাবদ্ধতা
- Admin panel শুধু সাম্প্রতিক ১০০টি প্রশ্ন/উত্তর দেখায়; user management, moderation, source verification,
  rate limiting, password reset ও advanced security এখনো যোগ করা হয়নি।
- AI নিজে থেকে নির্ভুল ইসলামিক দলিল যাচাই করতে পারে না। নির্ভরযোগ্য কুরআন/হাদিস ডেটাবেস ও
  আলেম-পর্যালোচিত কনটেন্ট পরবর্তী ধাপে যুক্ত করতে হবে।
