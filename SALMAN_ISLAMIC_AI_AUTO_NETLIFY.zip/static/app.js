const $=id=>document.getElementById(id);
let history=[];
const library=[
 {title:"ইসলামে বিবাহের উদ্দেশ্য",category:"বিবাহ ও পরিবার",body:"ইসলামে বিবাহ একটি দায়িত্বশীল পারিবারিক বন্ধন। এর মধ্যে প্রশান্তি, ভালোবাসা, দয়া, পারস্পরিক সম্মান এবং দায়িত্ব পালনের শিক্ষা রয়েছে।"},
 {title:"দাম্পত্য জীবনে সদাচরণ",category:"স্বামী–স্ত্রীর অধিকার",body:"স্বামী ও স্ত্রী উভয়েরই উচিত একে অপরের সঙ্গে সম্মান, কোমলতা ও ন্যায়সঙ্গত আচরণ করা। মনোযোগ দিয়ে কথা শোনা, ভুল হলে ক্ষমা চাওয়া এবং মতভেদ হলে শান্তভাবে আলোচনা করা ভালো অভ্যাস।"},
 {title:"পরিবারে পরামর্শ ও ধৈর্য",category:"বিবাহ ও পরিবার",body:"পরিবারের সিদ্ধান্তে পারস্পরিক পরামর্শ, ধৈর্য ও দায়িত্বশীলতা গুরুত্বপূর্ণ। সমস্যা বড় হলে বিশ্বস্ত অভিভাবক বা উপযুক্ত পরামর্শদাতার সাহায্য নেওয়া যেতে পারে।"},
 {title:"সত্যবাদিতা ও আমানতদারি",category:"ইসলামিক জ্ঞান",body:"সত্য বলা, প্রতিশ্রুতি রক্ষা করা এবং অন্যের অধিকার সংরক্ষণ করা ইসলামের গুরুত্বপূর্ণ নৈতিক শিক্ষা।"},
 {title:"শিক্ষণীয় গল্প: দয়া",category:"ইসলামিক গল্প",body:"একজন মানুষ নিয়মিত প্রতিবেশীর খোঁজ নিতেন এবং প্রয়োজন হলে সাহায্য করতেন। তাঁর ছোট ছোট ভালো কাজ এলাকায় সৌহার্দ্য তৈরি করল। শিক্ষা—দয়া ও ভালো ব্যবহার সমাজকে সুন্দর করে।"}
];
function bubble(text,who=""){const el=document.createElement("div");el.className="bubble "+who;el.textContent=text;$("messages").appendChild(el);$("messages").scrollTop=$("messages").scrollHeight;return el}
function renderLibrary(){library.forEach(a=>{const card=document.createElement("article");card.className="card";const h=document.createElement("h3");h.textContent=a.title;const c=document.createElement("p");c.className="small";c.textContent=a.category;const b=document.createElement("p");b.textContent=a.body;card.append(h,c,b);$("articles").append(card)})}
$("chatForm").addEventListener("submit",async e=>{
 e.preventDefault();const q=$("question").value.trim();if(!q)return;
 $("question").value="";$("sendBtn").disabled=true;bubble(q,"user");const wait=bubble("উত্তর তৈরি হচ্ছে…");
 try{
  const r=await fetch("/.netlify/functions/chat",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({message:q,history})});
  const d=await r.json();wait.remove();if(!r.ok)throw new Error(d.error||"উত্তর পাওয়া যায়নি।");
  bubble(d.answer);history.push({role:"user",content:q},{role:"assistant",content:d.answer});history=history.slice(-12);
 }catch(err){wait.textContent=err.message}
 finally{$("sendBtn").disabled=false}
});
renderLibrary();
