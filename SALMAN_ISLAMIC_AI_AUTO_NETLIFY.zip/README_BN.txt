SALMAN ISLAMIC AI — AUTO CHAT VERSION (NETLIFY)

এই ভার্সনে Admin Panel সম্পূর্ণ বাদ দেওয়া হয়েছে। ভিজিটররা সরাসরি AI Chat-এ প্রশ্ন করলে AI স্বয়ংক্রিয়ভাবে উত্তর দেবে। আপনার দেওয়া Quran/Tasbih profile image header-এ যুক্ত আছে।

Deploy:
1) ZIP extract করে সব ফাইল GitHub repository-র root-এ upload/commit করুন।
2) Netlify > Add new site > Import an existing project > GitHub repository নির্বাচন করুন।
3) Build command ফাঁকা রাখুন, Publish directory "." দিন (netlify.toml-এ সেট করা আছে)।
4) Deploy করুন।
5) Netlify Site configuration / Project configuration > Environment variables-এ:
   OPENAI_API_KEY = আপনার OpenAI API key
   OPENAI_MODEL = gpt-4.1-mini (অথবা আপনার API account-এ উপলভ্য model ID)
6) Environment variables save করে নতুন deploy দিন (functions-এর জন্য redeploy প্রয়োজন হতে পারে)।

গুরুত্বপূর্ণ:
- ChatGPT subscription এবং OpenAI API billing আলাদা। API key ও API billing লাগতে পারে।
- API key কখনো GitHub বা HTML/JS ফাইলে দেবেন না; শুধু Netlify Environment Variables-এ রাখবেন।
- AI ভুল করতে পারে। কুরআন-হাদিসের সূত্র যাচাই করুন। তালাক, উত্তরাধিকার, নির্যাতন বা জটিল ফতোয়ার জন্য যোগ্য আলেমের পরামর্শ নিন।
- Admin panel বা database এই সংস্করণে নেই; লাইব্রেরির নমুনা কনটেন্ট static ভাবে সাইটে আছে।
