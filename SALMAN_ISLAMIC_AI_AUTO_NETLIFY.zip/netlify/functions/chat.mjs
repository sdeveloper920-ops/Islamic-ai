const headers={"Content-Type":"application/json"};
export default async (req)=>{
 if(req.method!=="POST")return new Response(JSON.stringify({error:"Method not allowed"}),{status:405,headers});
 try{
  const {message,history=[]}=await req.json();
  if(typeof message!=="string"||!message.trim()||message.length>3000)
   return new Response(JSON.stringify({error:"প্রশ্ন লিখুন (সর্বোচ্চ ৩০০০ অক্ষর)।"}),{status:400,headers});
  const key=Netlify.env.get("OPENAI_API_KEY");
  const model=Netlify.env.get("OPENAI_MODEL")||"gpt-4.1-mini";
  if(!key)return new Response(JSON.stringify({error:"AI এখনো চালু করা হয়নি। সাইটের মালিককে Netlify-তে OPENAI_API_KEY সেট করতে হবে।"}),{status:503,headers});
  const system=`তুমি SALMAN ISLAMIC AI—বাংলাভাষী ইসলামিক তথ্য-সহায়ক। সম্মানজনক, শান্ত, সহজ ও পরিষ্কার বাংলায় উত্তর দাও।
ইসলাম, কুরআন, হাদিস, আকিদা, ইবাদত, আখলাক, বিবাহ, স্বামী-স্ত্রীর পারস্পরিক অধিকার ও দায়িত্ব, পরিবার, সন্তান লালন-পালন, ইসলামিক ইতিহাস এবং শিক্ষণীয় গল্প নিয়ে প্রশ্নের উত্তর দাও।
কুরআন/হাদিসের উদ্ধৃতি, আরবি, সূত্র, হাদিস নম্বর বা ফিকহি মত নিশ্চিত না হলে বানিয়ে বলবে না; অনিশ্চয়তা স্পষ্ট করবে। কোনো গল্পকে যাচাইকৃত ঐতিহাসিক ঘটনা বলবে না যদি তা নিশ্চিত না হও।
বিবাহ ও দাম্পত্য বিষয়ে উভয়ের সম্মান, সম্মতি, নিরাপত্তা ও ন্যায়সঙ্গত আচরণ গুরুত্ব দেবে। ব্যক্তিগত/জটিল ফতোয়া, তালাক, উত্তরাধিকার, নির্যাতন, চিকিৎসা বা আইনি বিষয়ে চূড়ান্ত সিদ্ধান্ত দেবে না; যোগ্য আলেম/বিশেষজ্ঞের সাহায্য নিতে বলবে।
কোনো প্রশ্নের উত্তর জানা না থাকলে তা স্পষ্টভাবে বলবে। অশ্লীল বা ক্ষতিকর আলোচনা এড়িয়ে শালীন ও শিক্ষামূলক উত্তর দেবে।`;
  const safeHistory=Array.isArray(history)?history.slice(-8).filter(x=>["user","assistant"].includes(x.role)&&typeof x.content==="string").map(x=>({role:x.role,content:x.content.slice(0,2500)})):[];
  const response=await fetch("https://api.openai.com/v1/chat/completions",{method:"POST",headers:{"Authorization":`Bearer ${key}`,"Content-Type":"application/json"},body:JSON.stringify({model,messages:[{role:"system",content:system},...safeHistory,{role:"user",content:message.trim()}],max_completion_tokens:900})});
  const data=await response.json();
  if(!response.ok)return new Response(JSON.stringify({error:"AI API-তে সমস্যা হয়েছে। API Key, model এবং API billing/settings যাচাই করুন।"}),{status:502,headers});
  return new Response(JSON.stringify({answer:data.choices?.[0]?.message?.content||"দুঃখিত, উত্তর তৈরি করা যায়নি।"}),{status:200,headers});
 }catch(e){return new Response(JSON.stringify({error:"সার্ভারে সংযোগ সমস্যা হয়েছে। পরে আবার চেষ্টা করুন।"}),{status:500,headers})}
};