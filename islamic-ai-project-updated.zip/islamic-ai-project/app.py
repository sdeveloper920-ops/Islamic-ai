import os
import sqlite3
import secrets
from functools import wraps
from flask import Flask, request, jsonify, render_template, session, redirect, url_for, flash
from openai import OpenAI

APP_SECRET = os.environ.get("APP_SECRET", "change-this-long-random-secret")
ADMIN_USERNAME = os.environ.get("ADMIN_USERNAME", "admin")
ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "")
OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY", "")
OPENAI_MODEL = os.environ.get("OPENAI_MODEL", "gpt-4.1-mini")
DATABASE_PATH = os.environ.get("DATABASE_PATH", "islamic_ai.db")

app = Flask(__name__)
app.secret_key = APP_SECRET
app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax")

SYSTEM_PROMPT = """
You are ISLAMIC AI, a friendly, thoughtful, general-purpose conversational assistant.
You can discuss everyday life and answer a wide range of appropriate questions, including
marriage and spouse communication, family relationships, parenting, education, technology,
science, writing, and general knowledge. Reply in the same language as the user (Bengali or English).
Be respectful, empathetic, practical, and clear. Do not assume the user's religion or personal situation.

For Islamic questions, explain carefully and respectfully using reliable Islamic knowledge.
Never invent Quran verses, hadith wording, references, authenticity grades, or scholarly consensus.
If you cannot verify a citation, clearly say so and do not fabricate one.
For differences among recognized schools of Islamic law, mention that views can differ and
avoid presenting one view as universal. For fatwas or high-stakes personal matters (divorce,
inheritance, medical issues, financial contracts, abuse, or complex worship questions), explain
that an AI response is not a fatwa and recommend consulting a qualified local scholar/mufti
or appropriate professional. Do not claim to be a scholar.
For health, legal, financial, or safety-critical questions, provide general information and
encourage qualified professional help when needed. Be transparent about uncertainty.
"""

def db():
    conn = sqlite3.connect(DATABASE_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with db() as conn:
        conn.execute("""CREATE TABLE IF NOT EXISTS chats (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id TEXT NOT NULL,
            question TEXT NOT NULL,
            answer TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )""")

@app.before_request
def ensure_db():
    init_db()

def admin_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not session.get("admin_logged_in"):
            return redirect(url_for("admin_login"))
        return fn(*args, **kwargs)
    return wrapper

@app.get("/")
def home():
    return render_template("index.html")

@app.get("/api/history")
def chat_history():
    user_id = session.get("chat_user_id")
    if not user_id:
        return jsonify(messages=[])
    with db() as conn:
        rows = conn.execute(
            "SELECT question, answer, created_at FROM chats WHERE user_id = ? ORDER BY id DESC LIMIT 30",
            (user_id,)
        ).fetchall()
    messages = []
    for row in reversed(rows):
        messages.append({"role": "user", "content": row["question"], "created_at": row["created_at"]})
        messages.append({"role": "assistant", "content": row["answer"], "created_at": row["created_at"]})
    return jsonify(messages=messages)

@app.post("/api/chat")
def chat():
    data = request.get_json(silent=True) or {}
    question = (data.get("message") or "").strip()
    if not question:
        return jsonify(error="Please enter a question."), 400
    if len(question) > 4000:
        return jsonify(error="প্রশ্নটি ৪০০০ অক্ষরের মধ্যে রাখুন।"), 400
    if not OPENAI_API_KEY:
        return jsonify(error="AI সার্ভার এখনো কনফিগার করা হয়নি। Hosting Environment Variables-এ OPENAI_API_KEY যোগ করতে হবে।"), 503

    user_id = session.get("chat_user_id")
    if not user_id:
        user_id = secrets.token_urlsafe(18)
        session["chat_user_id"] = user_id

    try:
        # Load recent turns for this browser session so the assistant can follow the conversation.
        with db() as conn:
            rows = conn.execute(
                "SELECT question, answer FROM chats WHERE user_id = ? ORDER BY id DESC LIMIT 10",
                (user_id,)
            ).fetchall()
        history = []
        for row in reversed(rows):
            history.append({"role": "user", "content": row["question"]})
            history.append({"role": "assistant", "content": row["answer"]})

        client = OpenAI(api_key=OPENAI_API_KEY)
        response = client.chat.completions.create(
            model=OPENAI_MODEL,
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                *history,
                {"role": "user", "content": question}
            ],
            temperature=0.3,
            max_tokens=1200
        )
        answer = response.choices[0].message.content or "দুঃখিত, উত্তর তৈরি করা যায়নি।"
        with db() as conn:
            conn.execute(
                "INSERT INTO chats(user_id, question, answer) VALUES (?, ?, ?)",
                (user_id, question, answer)
            )
        return jsonify(answer=answer)
    except Exception:
        app.logger.exception("AI request failed")
        return jsonify(error="AI সার্ভারে সাময়িক সমস্যা হয়েছে। পরে আবার চেষ্টা করুন।"), 502

@app.get("/admin")
@admin_required
def admin():
    with db() as conn:
        total = conn.execute("SELECT COUNT(*) n FROM chats").fetchone()["n"]
        rows = conn.execute("SELECT id, question, answer, created_at FROM chats ORDER BY id DESC LIMIT 100").fetchall()
    return render_template("admin.html", total=total, rows=rows)

@app.route("/admin/login", methods=["GET", "POST"])
def admin_login():
    if request.method == "POST":
        username = request.form.get("username", "")
        password = request.form.get("password", "")
        if not ADMIN_PASSWORD:
            flash("সার্ভারে ADMIN_PASSWORD সেট করা হয়নি।", "error")
        elif secrets.compare_digest(username, ADMIN_USERNAME) and secrets.compare_digest(password, ADMIN_PASSWORD):
            session.clear()
            session["admin_logged_in"] = True
            return redirect(url_for("admin"))
        else:
            flash("Username অথবা password সঠিক নয়।", "error")
    return render_template("login.html")

@app.post("/admin/logout")
@admin_required
def admin_logout():
    session.clear()
    return redirect(url_for("home"))

@app.get("/health")
def health():
    return jsonify(status="ok")

if __name__ == "__main__":
    port = int(os.environ.get("PORT", "5000"))
    app.run(host="0.0.0.0", port=port)
